from random import randint
dice_image = ["0",'0','0','0','0','0']
dice_num = randint( 0,5)
print(dice_image[dice_num])