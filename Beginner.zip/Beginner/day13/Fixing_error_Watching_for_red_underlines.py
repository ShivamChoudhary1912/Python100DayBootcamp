try:
    age = int(input("How old are you?"))
except ValueError:
    print("You have typed in a an invalid number. Please try again with numerical responce such as 15.")
    age = int(input("How old are you?"))
if(age >10):
    print("You can drive at {age}.")        