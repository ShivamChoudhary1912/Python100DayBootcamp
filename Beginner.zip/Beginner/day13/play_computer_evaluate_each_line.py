year = int(input("What's your birth?"))

if year > 1980 and year < 1994:
    print("You are a millennial.")
elif year >= 1994 :
    print("You are a Gen Z.")    