#   How to Check the User Answer
import random


print('''  _                                             
| |                                            
| |__   __ _ _ __   __ _ _ __ ___   __ _ _ __  
| '_ \ / _` | '_ \ / _` | '_ ` _ \ / _` | '_ \ 
| | | | (_| | | | | (_| | | | | | | (_| | | | |
|_| |_|\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                    __/ |                      
                   |___/                       ''')

HANGMANPICS = ['''
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
========='''
, 
'''
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
========='''
,
 '''
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========''' 
, '''
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========''',
 
'''
  +---+
  |   |
  O   |
  |   |
      |
      |
=========''',
 
'''
  +---+
  |   |
  O   |
      |
      |
      |
=========''',
'''
  +---+
  |   |
      |
      |
      |
      |
=========''']



lives =6
print(f"total lives is {lives}")

word_list = ["ardvark" , "baboon" , "camel" ]
chosen_word = random.choice(word_list)
print(f'Pssst, the solution is ')
display = []
for _ in range(len(chosen_word)):
    display += "_"
end_of_game = False
while not end_of_game:
         
    input1 = input("guess the letters:\n")
    guess = input1.lower()
    
    if guess in display:
        print(f"You have already guessed {guess}, That's not in the word .You Lose a Life. ")
    for position in range(len(chosen_word)):
        letter = chosen_word[position]
       # print(f'Current position : {position}\n Current letter :{letter}\n letter:{guess}')
        if  letter == guess:
            display[position] += guess
        #else :
           # print("not match")    
    if guess not in chosen_word :
        lives =lives-1
        if lives == 0:
            end_of_game = True
            print("you Lose ")
        
                    

    print(f"{' '.join(display)}") 
    
    if "_" not in display:
        end_of_game = True
        print("You Win.")
          
    print(HANGMANPICS[lives])   
    print(f"You Have left Life is {lives}")     
      

        
        

       


      
            