num_char = len(input("What is your name?\n"))
# print("your name has"+num_char+ "characters.")


#to know the type of data use "type"
    #print(type(len(input("What is your name?\n"))))

# to convert the one data type to another
new_num_char =str(num_char)
print("your name has"+new_num_char + "characters.")
print(type(new_num_char))
a = str(123)
print(type(a))
print(70+float("30.6"))