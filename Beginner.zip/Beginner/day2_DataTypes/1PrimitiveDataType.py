# data types

#String
print("Hello"[0])
print("456"+"123")

#integer
print(123 + 345)
123_456_789
#float
3.124

#boolean
True
False