#  print(round(8/3,2))

#print(8 // 3)
#result=4/2
#result /=2
#print(result)

score = 0
height =1.8
isWinning=True

# User score a point
score +=1
print("ypur score is"+" "+str(score)) 


#F-string
print(f"your score is {score},your height is {height},you are winning {isWinning}")
