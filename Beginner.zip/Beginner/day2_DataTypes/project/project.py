print("Welcome to the tip calculator!")
bill = float(input("What was the total bill?\n"))
print(f"Bill is ${bill}")
tip = float(input("How much tip in percentage would you like to give?\n"))
print(f"Tip is ${tip}")
tip_percent =tip/100
tip_amount = bill*tip_percent
print(f"tip amount is ${tip_amount}")
total_bill = bill + tip_amount
print(f"total bill is : ${total_bill}")
split_bill = int(input("How many people to split the bill?\n"))
print(f"{split_bill} people split the bill")
print("Each person shuld pay ? ")

Each_person_pay = total_bill/split_bill
print(f"Each person pay is ${Each_person_pay}")





