3 + 5
7 - 4
3 * 2
#print(type(6/2))
#print(2**3)

print(3*(3+3)/3-3)