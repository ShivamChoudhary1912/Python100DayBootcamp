print("welcome to the rollercoaster!")
height = int(input("what is your height in cm ?\n"))
bill = 0

if height >=120:
    print("you can ride the roller coaster!")
    age = int(input("what is your Age ?\n"))
    if age<12:
        bill =5
        print(f"Child Ticket price is $5")
    elif age <= 18:
        bill = 7
        print(f"Youth Ticket price is $7") 
            
    else:
        bill =12
        print(f"Adult Ticket price is $12")  

    wants_photo = input("Do you want a photo taken? Y or N.\n") 
    if wants_photo =="Y":
        bill = bill+3
        
    print(f"your final bill is {bill}")            
    
else:
    print("sorry , you have to grow taller to ride.")   


