#  nested if Else

# print("welcome to the rollercoaster!")
# height = int(input("what is your height in cm ?\n"))

# if height >=120:
#     print("you can ride the roller coaster!")
#     age = int(input("what is your Age ?\n"))
#     if age>18:
#         print("Ticket price is $12")
#     else:
#         print("Ticket price is $7")   
    
# else:
#     print("sorry , you have to grow taller to ride.")   



# ELIF
print("welcome to the rollercoaster!")
height = int(input("what is your height in cm ?\n"))

if height >=120:
    print("you can ride the roller coaster!")
    age = int(input("what is your Age ?\n"))
    if age<12:
        print("Ticket price is $5")
    elif age>=18:
        print("Ticket price is $12") 
            
    else:
        print("Ticket price is $7")   
    
else:
    print("sorry , you have to grow taller to ride.")   


