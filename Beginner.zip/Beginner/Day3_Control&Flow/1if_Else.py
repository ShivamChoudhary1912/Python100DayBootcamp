print("welcome to the rollercoaster!")
height = int(input("what is your height in cm ?\n"))

if height >=120:
    print("you can ride the roller coaster!")
    
else:
    print("sorry , you have to grow taller to ride.")    