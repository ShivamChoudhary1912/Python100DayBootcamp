def formate_name(f_name , l_name):
    if f_name == "" or l_name == "":
        return "You did not provide valid input"
    
    formated_f_name = f_name.title() 
    formate_l_name = l_name.title()
    return f"{formated_f_name} {formate_l_name}"
    
print(formate_name(input("What is your first name:"),input("what is your last name:")))

    