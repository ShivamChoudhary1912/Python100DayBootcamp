# def formate_name(f_name , l_name):
#     formated_f_name = f_name.title() 
#     formate_l_name = l_name.title()
#     return f"{formated_f_name} {formate_l_name}"
    
# output =formate_name('shivam','taliyan')
# print(output)
    
     
     
     
def function_1(text):
    return text+text

def function_2(text):
    return text.title()

output = function_2(function_1("hello"))  
print(output)   