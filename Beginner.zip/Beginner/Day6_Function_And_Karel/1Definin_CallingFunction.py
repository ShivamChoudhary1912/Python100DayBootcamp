# #defining Function
# def my_function():
#     print("hello world")
#     print("Bye")
    
# # Calling Function     
# my_function()

def turn_right():
    turn_left()
    turn_left()
    turn_left()
def my_move():
    move()
    turn_left()
    move()
    turn_right()
    move()
    turn_right()
    move()
    turn_left()
for step in range(6):
    my_move()

    