# for Loop with Range

# for number in range(1,11):
#     print(number)
    
    

# define the step between range


# for number in range(1,11,3):
#     print(number)

total =0
for number in range(1,101):
    total+=number
print(total)
