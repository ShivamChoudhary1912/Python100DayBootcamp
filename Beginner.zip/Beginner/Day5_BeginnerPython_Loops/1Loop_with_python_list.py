# print list item one by one using for Loop
fruits =["Apple","Peach","Pear"]
for fruit in fruits:
    print(fruit +",")
print(fruits)    
    