# Write your code here 👇

for name in range(1,101):
  
  if (name%3 == 0)and(name%5 == 0):
    print("FizzBuzz")
    
  elif name%3 == 0:
    print("Fizz")
    
  elif name%5 == 0:
    print("Buzz")
 
  else :
    print(name)
    
    
  
  
  
