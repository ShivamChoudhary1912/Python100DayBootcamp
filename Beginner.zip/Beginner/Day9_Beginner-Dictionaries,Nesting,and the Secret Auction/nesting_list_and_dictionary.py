capitals = {
    "Fraance": "Paris",
    "Germany": "Berlin",
}

# Nested List in Dictionary

travel_log = {
    "France" :["Paris","Lille","Dijon"],
    "Germany" :["Stutgart", "Berlin"],
    
}
# print Lille

print(travel_log["France"][1])

nested_List =["A","B",["c","D"]]
print(nested_List[2][1])

travel_log ={
    "france":{
        
        "cities_visiter": ["paris", "Lille", "Dijon"],
        "total_visits": 12
    },
    "Germany":{
        "cities_visited": ["Berlin", "Hamburg","Stuttgart"],
        "total_visits":5
    }
}
print(travel_log["Germany"]["cities_visited"][2])