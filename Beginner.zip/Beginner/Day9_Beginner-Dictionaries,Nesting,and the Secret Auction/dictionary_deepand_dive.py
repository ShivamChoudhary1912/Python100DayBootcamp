programming_dictionary ={
    "bug":"It may have been moved, edited, or deleted.",
    "function":"File not found",
    "loop":"ERR_FILE_NOT_FOUND"
}

print(programming_dictionary["bug"])

# adding new element in a dictionary
programming_dictionary["hi"]="sit boy is agood boy"

print(programming_dictionary)

# wipe an existing Dictionary
#programming_dictionary ={}
#print(programming_dictionary)

# editing  an item in a dictionary 
programming_dictionary["bug"] = "kannata bhaut kutiya hai"

print(programming_dictionary)
for key in programming_dictionary:
    print(key)
    print(programming_dictionary[key])