print('''
       ___________
                        
       \         /
        )_______(
        |"""""""|_.-._,.---------.,_.-._
        |       | | |               | | ''-.
        |       |_| |_             _| |_..-'
        |_______| '-' `'---------'` '-'
        )"""""""(
       /_________\
       `'-------'`
      .-------------. 
     /_______________\
         
         
      ''')

print("Welcome to The secret Auction Program.")


bids ={}
continue_bidding = True


def find_heighest_bidder(bidding_dictionary):
      
      heighest_bid = 0
      winner =" "
      max(bidding_dictionary)
      for bidder in bidding_dictionary:
            bid_amount =bidding_dictionary[bidder]
            heighest_bid = bid_amount
            if bid_amount >heighest_bid:
                heighest_bid = bid_amount
                winner = bidder
      print(f"The winner is {winner} with a bid of ${heighest_bid} ")            





while(continue_bidding):
      name_input = input("What is Your name?:")
      bid_price = int(input("What is your bid?: $"))

      bids[name_input] = bid_price

      should_continue = input("Are there any other bidders? Type 'yes' or 'no'. \n ").lower() 
      if should_continue =="no":
            continue_bidding = False
            find_heighest_bidder(bids)
      
      elif should_continue == "yes":
            print("\n" * 20)      
            

# compare bids in dictionary


                  
            
            
      
                   
      
      
      
