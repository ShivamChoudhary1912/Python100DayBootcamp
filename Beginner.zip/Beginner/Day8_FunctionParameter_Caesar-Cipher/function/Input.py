def greet():
    print("Hello")
    print("How do you do ?")
    print("Is't the whether nice? ")
    
greet()  

# function that allow for inputs
def greet_with_name(name):
    print(f"Hello {name}")
    print(f"How do you do {name}?")
greet_with_name("Shivam")      