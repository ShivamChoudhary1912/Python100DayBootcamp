import random
Easy_Level_Turns = 10
Hard_Level_Turns = 5
def set_difficulty():
    level = input("Choose a difficulty.Type 'easy' or 'hard' :").lower()
    if level == "easy":
        
        return Easy_Level_Turns
    else:
        return Hard_Level_Turns
            

def compare(guess_number,Thinking_number,turns):
    """ Check answer against guess, returns the number of turns remaining."""
    
    if guess_number==Thinking_number: 
        print(f"You got it! The answer was {guess_number}")   
        
    elif guess_number < Thinking_number:
        print(f"Too low.") 
        return turns - 1
        
    else:
        print(f"Too High.") 
        return turns - 1
     
              
             
    
logo = '''

                              __                                                  
 |\ |     ._ _  |_   _  ._   /__      _   _  _ o ._   _    ._  ._ _  o  _   _ _|_ 
 | \| |_| | | | |_) (/_ |    \_| |_| (/_ _> _> | | | (_|   |_) | (_) | (/_ (_  |_ 
                                                      _|   |        _|            


'''     


def game():
    # choosing a random number  between 1 and 100  
    print(logo)
            
    print("Welcome to the Number Guessing Game.")
    print("I am thinking of a number between 1 and 100.")
    Thinking_number = random.randint(1,100)

    # Let the user guess a number
    turns = set_difficulty()
    
    

    # Let the user guess a number 
    guess_number =0
    while  guess_number!= Thinking_number: 
        print(f"You have {turns} attempts remaining to guess the number.")
        guess_number = int(input("Make a guess: "))
        turns=compare(guess_number,Thinking_number,turns)
        if turns ==0:
            print("You have run out of guesses, you lose.")
            return
        elif guess_number!=Thinking_number:
            print("Guess again.")
    # Track the number of turns reduce by 1 if they get it wrong     
game()        

               



