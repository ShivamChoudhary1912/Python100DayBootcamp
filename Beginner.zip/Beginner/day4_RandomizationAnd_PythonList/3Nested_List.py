# Nested List
fruits = ["strawberries","Nectarines","Apples","Peaches","Cherries","Pears"]
vegetables =["Spinach","Kale","Tomatoes","Celery","Potatoes"]

dirty_dozen =[fruits,vegetables]
print(dirty_dozen[1][1])