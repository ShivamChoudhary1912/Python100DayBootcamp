import random

a =1
b=3
# print random integer between a and b also include a and b 
random_integer = random.randint(a,b)
print(random_integer)
# print  random floating number between  0 and 1 and not including 1
# 0.0000000  - 0.99999999999----


random_float = random.random()
print(random_float)

love_score = random.randint(1,100)
print(f"Your love score is {love_score}")

