import random

rock ='''

   _______
---'   ____)  
      (_____)  
      (_____)  
      (____)
---.__(___)  
'''
paper =  '''  _______
---'   ____)____  
          ______)  
          _______)  
         _______)
---.__________)  
'''

Scissors = '''
  _______
---'   ____)____  
          ______)  
       __________)  
      (____)
---.__(___)  
'''  
user_choice =int(input("What do you choose? Type 0 for Rock, 1 For Paper or 2 for Scissors.\n"))
error =0
game_image =[rock,paper,Scissors]
print(f"User Choose {user_choice}")
if user_choice ==0:
    print(" (Rock)")
    print(game_image[user_choice])
elif user_choice == 1:
        print("(Paper)")
        print(game_image[user_choice])
elif user_choice == 2:
        print("(Scissors)") 
        print(game_image[user_choice])     
else :
    print("wrong Choice . Please choose Again") 
    error+=1
if error==1:
    print("Something went Wrong . Please try again.")    
else:
    computer_choice =random.randint(0,2)
print(f"Computer Choose {computer_choice}")
if computer_choice ==0:
    print("(Rock)")
    print(game_image[computer_choice])  
elif computer_choice == 1:
        print("(Paper)")
        print(game_image[computer_choice])  
elif computer_choice == 2:
        print(" (Scissors)") 
        print(game_image[computer_choice])       
else :
    print("wrong Choice . Please choose Again") 
    


if computer_choice == user_choice:
    print("Game Drawn")    
    print("Please play again")
elif (computer_choice ==0) and (user_choice == 1):
    print("User Wins")
    
elif (computer_choice ==0) and (user_choice == 2):
    print("Computer Wins and You Lose")
elif (computer_choice ==1) and (user_choice == 0):
    print("Computer Wins and You Lose")
    
elif (computer_choice ==1) and (user_choice == 2):
    print("User Wins") 
elif (computer_choice ==2) and (user_choice == 0):
    print("User Wins")
    
elif (computer_choice ==2) and (user_choice == 1):
    print("Computer Wins and You Lose")       
    
        
        
    
    
     
 
             
        
        


         