states_of_America = ["Delaware","Pennsylvania","New Jersey","Georgia","Connecticut","Marryland","New York\n"]
print(states_of_America)
# 0 represent starting list item 
print(states_of_America[0])
# -1 represent Ending list item

print(states_of_America[-1])

# update the list element at index 1
states_of_America[1] = "Pencilvania"
print(states_of_America) 

# "append" is used to add the item in List
states_of_America.append("hi")
print(states_of_America)

# "extend" is used to add more than one item in list
states_of_America.extend(["Angelaland","Jack Bauer Land"])
print(states_of_America)