# There are two variables, a and b
a = input()
b = input()
# Create a third variable to help switch the values
c = a
a = b
b = c

print("a: " + a)
print("b: " + b)