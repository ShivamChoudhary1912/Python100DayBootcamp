name =input("what is your name ")
print(name)

hi = "hii"
print(hi)

hi = "bye"
print(hi)

name = input("What is your name?")
length =len(name)
print(length)