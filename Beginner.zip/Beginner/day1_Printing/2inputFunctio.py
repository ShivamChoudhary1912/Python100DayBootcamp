# single line comments we use "#"

print("hello "+input("What is your name ?"))
print("enter  numbers :")
num1 =int(input("first number is "))
num2 =int(input("second number is"))
print("result is"+num1*num2)


