print("Hello world ")
print(6)